import numpy as np
import matplotlib.pyplot as plt
from astropy.io import fits
import os
import scipy
from scipy import interp
from scipy import signal
import math
import pdb
import sys

#readpath = '/Users/aiyer/MAST_2018-03-23T1255/HST/LB5N13020/'
#readpath_obj57  = r'C:/Users/alexl/OneDrive/Documents/Spring_2018/AST 523/MAST_2018-03-23T1257/MAST_2018-03-23T1257/HST/LCD905010/'
readpath_obj00 = r'C:\Users\TheMothership\OneDrive\Documents\Spring_2018\AST 523\MAST_2018-03-23T1300\MAST_2018-03-23T1300\HST\LB1V15010'
readpath_obj57 = 'C:\Users\TheMothership\OneDrive\Documents\Spring_2018\AST 523\MAST_2018-03-23T1257\MAST_2018-03-23T1257\HST\LCD905010'



obj1= 'lcd905010_x1dsum.fits'
obj2='lb1v15010_x1dsum.fits'

a = fits.open(obj1)

a.info()

hdu = a[1]

with open('test.txt', 'w') as f: f.write(repr(hdu.header))

pdb.set_trace()

sys.exit()


w = a[1].data['WAVELENGTH']
f = a[1].data['FLUX']

print w.shape
print f.shape



def moving_average(a, n=3) :
    #n is the number of points to average
    ret = np.cumsum(a, dtype=float)
    ret[n:] = ret[n:] - ret[:-n]
    return ret[n - 1:] / n

def gaussfold(lam, flux, fwhm):
    #more reading info http://www.igorexchange.com/node/2985
    lammin=min(lam)
    lammax=max(lam)
    dlambda=fwhm/17.
    interlam=np.arange(lammin,lammax,dlambda)
    interflux=interp(interlam,lam,flux)
    fwhm_pix=fwhm/dlambda
    window=math.floor(17*fwhm_pix)

    #constructing a normalized gaussian who's width is FWHM
    std=0.5*fwhm_pix/math.sqrt(2*math.log(2))
    gauss1=scipy.signal.gaussian(window,std=std)
    gauss=gauss1/np.trapz(gauss1)

    # pdb.set_trace()
    #convovle flux array with gaussian
    fold=np.convolve(interflux,gauss,mode='same')
    #interpolate back to original grid
    fluxfold=interp(lam,interlam,fold)
    #pdb.set_trace()
    return fluxfold

#this running/boxvar mean thing doesn't work so well here
# wbin = moving_average(w[0],100)
# fbin = []
# fbin.append(np.average(f[0][np.where((w[0] >= w[0][0]) & (w[0] < wbin[0]))]))
# for i in range(len(wbin[1:])):
#     loc1 = np.where((w[0] >= wbin[0+i]) & (w[0] < wbin[1+i]))
#     fbin.append(np.average(f[0][loc1]))

#R is the new spectral resolution, R = lambda / delta lamda
R = 20000
fwhm = 1./R * np.mean(w[0])
fbin = gaussfold(w[0],f[0],fwhm)
#

##################
#plots
##################

fig, (ax1,ax2) = plt.subplots(2,1)

ax1.plot(w[0],f[0],color='b', label = 'data')
ax2.plot(w[0],fbin,color='k', label='reduction')
ax2.set_xlabel('Wavelength')
ax1.set_ylabel('Flux')
ax2.set_ylabel('Flux')
# plot(w[1],f[1],color='b')
ax1.legend()
ax2.legend()
plt.show()
